<section id="section_six">
	
	<div id="sec_six_inner" class="content">
		
		<div class='sec_six_col'>
		
			<?php the_field( 'section_six_column_one' ); ?>

		</div><!-- sec_six_col -->

		<div class='sec_six_col'>
		
			<?php the_field( 'section_six_column_two' ); ?>
		
		</div><!-- sec_six_col -->
		
	</div><!-- sec_six_inner -->
	
</section><!-- section_six -->