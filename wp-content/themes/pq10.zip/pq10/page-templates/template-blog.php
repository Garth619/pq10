<?php
	
	/* Template Name: Blog */ ?>
