<?php 
	
	/* Template Name: Home */
	
	get_header();


	get_template_part( 'page-templates/includes/homepage_template_parts/section', '1' );
	get_template_part( 'page-templates/includes/homepage_template_parts/section', '2' );
	get_template_part( 'page-templates/includes/homepage_template_parts/section', '3' );
	get_template_part( 'page-templates/includes/homepage_template_parts/section', '4' );
	get_template_part( 'page-templates/includes/homepage_template_parts/section', '5' );
	get_template_part( 'page-templates/includes/homepage_template_parts/section', '6' );
	get_template_part( 'page-templates/includes/homepage_template_parts/section', '7' );
	
	get_footer(); ?>

