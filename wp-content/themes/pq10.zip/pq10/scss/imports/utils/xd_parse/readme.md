`php /Applications/MAMP/htdocs/pq1/wp-content/themes/pq1/scss/imports/utils/xd_parse/run_parse.php`

`json-to-scss /Applications/MAMP/htdocs/pq1/wp-content/themes/pq1/scss/imports/utils/xd_parse/scss/map/_xd_map.json`